<!DOCTYPE HTML>
<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="css/style.css">
</
	<title>Customer Registration</title>
</head>
<body>
<div class="body">
</div>
<div class="grad"></div>
		<div class="header">
			<div>Register a <br>
            <span>Parcel</span></div>
		</div>
		<br>
		<div class="login">
           <form action="insertParcel.php" method="post">
<br/>
				<input id="customer_Name" name="customer_Name" placeholder="Name" type="text">
        		<input id="pickup_address" name="pickup_address" placeholder="Pickup Address" type="text">
				<input id="delivery_address" name="delivery_address" placeholder="Delivery Address" type="text"><br/>
                <input id="package_type" name="package_type" placeholder="Package Type" type="text"><br/>
				<input id="contact_no" name="contact_no" placeholder="Contact No" type="text"><br/>
                <input id="state_address" name="state_address" placeholder="State Address" type="text"><br/>
                <input id="note" name="note" placeholder="Note" type="text"><br/>
                					

				<input name="submit" type="submit" value="Register">
                               
				</form>      
</body>



</html>
